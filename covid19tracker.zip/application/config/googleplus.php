<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = '';
$config['googleplus']['client_id']        = '980908373901-1aulvovfhoihela49f146jst68s1n9lr.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'zcJlTSpFDKfovBtVuRjERre2';
$config['googleplus']['redirect_uri']     = 'http://politicalmarkaz.com/googleplussignin/';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

