<?php
$lang['home'] 									= "Home";
$lang['latestAnalysis'] 						= "Latest Analysis";
$lang['latestArticles'] 						= "Latest Articles";
$lang['country'] 								= "Country";
$lang['gallery'] 								= "Gallery";
$lang['aboutus'] 								= "معلومات عنا";

?>	